# BK001 行網緊急 Facebook／Instagram／WeChat 模擬投單（20260918）

來源：`/Users/ryanchen/Downloads/CIB-電信自測調取條件-20260729_Mobile_v3.xlsx` 之 `OTT_APP調取` sheet，SHA-256：`e8abc40a9907ac7d3ba6a9d25c3f618f0b63895a1ca07668385f391e5b0fd735`。
本包依使用者指定建立4張BK001明文模擬華電投單，每張1個`queryItem`。

| 編號 | 測項 | appType | Asia/Taipei時間 | 結果類型 | Payload |
|---|---|---|---|---|---|
| 1.7 | Facebook voice call OTT辨識紀錄 | `Facebook/Instagram Voice Calls` | 2026-07-14 15:00:36～15:00:46 | `1` (OTT only) | `create/CRIT-17-FBVOICE.json` |
| 1.9 | Instagram voice call OTT辨識紀錄 | `Facebook/Instagram Voice Calls` | 2026-07-14 15:00:36～15:00:46 | `1` (OTT only) | `create/CRIT-19-IGVOICE.json` |
| 2.5 | WeChat辨識紀錄 | `WeChat Message` | 2026-07-14 15:50:23～15:50:24 | `0` (IPDR) | `create/CRIT-25-WECHAT.json` |
| 1.12 | Instagram video call OTT辨識紀錄 | `Facebook/Instagram Video Calls` | 2026-07-14 15:12:08～15:12:18 | `1` (OTT only) | `create/CRIT-112-IGVIDEO.json` |

## 共用設定

- 行網：`targetCarrier=FET`。
- 緊急：`priority=Critical`，後端映射為`docPriority=critical`，系統顯示「最速件」。
- 使用者未另行指定去識別化，沿用同來源既有測試包：`deidentifyFlag=1`。
- 1.7、1.9、1.12使用`ipdrOttFlag=1`與單一`_OTT.gpg`結果檔。
- 2.5使用`ipdrOttFlag=0`與單一`_IPDR.gpg`結果檔。
- 時間依來源Excel視為`Asia/Taipei`，payload轉為UTC `Z`。
- 來源Excel的Facebook與Instagram Voice／Video共用APP Signature，payload依原值送出。

## 驗證與執行

```bash
UV_CACHE_DIR=/private/tmp/cib-uv-cache uv run --offline --python 3.12   --with openpyxl==3.1.5 python validate_package.py

kubectl -n cib port-forward service/cibfn-back-api-service 18080:8080
export BK001_ENDPOINT='http://127.0.0.1:18080/api/ipdr/submission/create'
export BK002_ENDPOINT='http://127.0.0.1:18080/api/ipdr/submission/status'

./send-one.sh create/CRIT-17-FBVOICE.json
./query-status.sh status/CRIT-17-FBVOICE-status.json
BK001_RUN_ALL_CONFIRM=YES ./run-all.sh
```

如要用新的`run-id`重新產生UUID與整包資料：

```bash
UV_CACHE_DIR=/private/tmp/cib-uv-cache uv run --offline --python 3.12   --with openpyxl==3.1.5 python generate_payloads.py --run-id <新run-id>
```

若走HTTPS Gateway，請設定`BK001_AUTHORIZATION`、`BK001_CLIENT_ID`、
`BK001_SUBSCRIPTION_KEY`與`BK001_CA_FILE`。正式TLS驗收不可使用
`BK001_INSECURE=1`。`_ALL.json`僅供人工檢視，不可直接POST。

## SQL核對

```sql
SELECT
    dqf.submission_id,
    od.lea_case_id,
    od.doc_priority,
    q.submission_item_id,
    q.query_status,
    q.query_start_time,
    q.query_end_time,
    q.app_type,
    q.ipdr_ott_flag,
    q.result_cib_path
FROM cibfn.tb_official_doc od
JOIN cibfn.tb_doc_query_form dqf ON dqf.official_doc_id = od.official_doc_id
JOIN cibfn.tb_query q ON q.doc_query_form_id = dqf.doc_query_form_id
WHERE od.lea_case_id LIKE 'FET-SELFTEST-20260918-CRIT-%'
ORDER BY od.lea_case_id;
```

此為明文`queryItems`地端功能測試資料，不代表華電正式`queryParameters`
GPG加密、簽章或密文竄改。
