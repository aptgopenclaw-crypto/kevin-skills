#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.12"
# dependencies = [
#   "openpyxl==3.1.5",
# ]
# [tool.uv]
# exclude-newer = "2026-09-18T00:00:00Z"
# ///

from __future__ import annotations

import hashlib
import json
import os
import uuid
from datetime import datetime
from pathlib import Path

from openpyxl import load_workbook


ROOT = Path(__file__).resolve().parent


def load_json(path: Path) -> object:
    return json.loads(path.read_text(encoding="utf-8"))


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> int:
    manifest = load_json(ROOT / "manifest.json")
    source = Path(manifest["sourcePath"])
    require(source.is_file(), f"找不到來源Excel: {source}")
    actual_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    require(actual_hash == manifest["sourceSha256"], "來源Excel SHA-256不符")
    require(manifest["sheet"] == "OTT_APP調取", "來源sheet不符")
    require(manifest["sourceRows"] == [8, 10, 18, 13], "來源列順序不符")
    require(manifest["sourceNumbers"] == ["1.7", "1.9", "2.5", "1.12"], "來源編號不符")
    require(manifest["networkType"] == "MOBILE", "networkType不符")
    require(manifest["targetCarrier"] == "FET", "targetCarrier不符")
    require(manifest["deidentifyFlag"] == "1", "deidentifyFlag不符")
    require(manifest["priority"] == {
        "requestedLabel": "緊急",
        "apiValue": "Critical",
        "systemValue": "critical",
        "systemLabel": "最速件",
    }, "緊急priority映射不符")
    require(manifest["submissionCount"] == 4, "submissionCount不符")
    require(manifest["queryItemCount"] == 4, "queryItemCount不符")
    require(manifest["ottCount"] == 3, "OTT數量不符")
    require(manifest["ipdrCount"] == 1, "IPDR數量不符")
    require(manifest["qgwTicketCountIfAllReleased"] == 4, "QGW ticket數量不符")

    expected = {
        "CRIT-17-FBVOICE": {
            "sourceNo": "1.7",
            "appType": "Facebook/Instagram Voice Calls",
            "flag": "1",
            "start": "2026-07-14T07:00:36Z",
            "end": "2026-07-14T07:00:46Z",
        },
        "CRIT-19-IGVOICE": {
            "sourceNo": "1.9",
            "appType": "Facebook/Instagram Voice Calls",
            "flag": "1",
            "start": "2026-07-14T07:00:36Z",
            "end": "2026-07-14T07:00:46Z",
        },
        "CRIT-25-WECHAT": {
            "sourceNo": "2.5",
            "appType": "WeChat Message",
            "flag": "0",
            "start": "2026-07-14T07:50:23Z",
            "end": "2026-07-14T07:50:24Z",
        },
        "CRIT-112-IGVIDEO": {
            "sourceNo": "1.12",
            "appType": "Facebook/Instagram Video Calls",
            "flag": "1",
            "start": "2026-07-14T07:12:08Z",
            "end": "2026-07-14T07:12:18Z",
        },
    }

    create_files = sorted((ROOT / "create").glob("CRIT-*.json"))
    status_files = sorted((ROOT / "status").glob("CRIT-*-status.json"))
    require(len(create_files) == 4, f"create數量錯誤: {len(create_files)}")
    require(len(status_files) == 4, f"status數量錯誤: {len(status_files)}")

    seen_cases: set[str] = set()
    submission_ids: set[str] = set()
    item_ids: set[str] = set()
    for metadata in manifest["submissions"]:
        case_id = metadata["caseId"]
        require(case_id in expected, f"非預期case: {case_id}")
        require(case_id not in seen_cases, f"重複case: {case_id}")
        seen_cases.add(case_id)
        expected_case = expected[case_id]
        require(metadata["sourceNo"] == expected_case["sourceNo"], f"{case_id}: sourceNo不符")

        payload = load_json(ROOT / metadata["createFile"])
        request = payload["lawfulRequest"]
        header = request["requestHeader"]
        criteria = request["queryCriteria"]
        require(len(criteria["queryItems"]) == 1, f"{case_id}: queryItems必須為1筆")
        query = criteria["queryItems"][0]

        require(header["leaCaseId"].startswith("FET-SELFTEST-"), f"{case_id}: leaCaseId前綴不符")
        require(header["targetCarrier"] == "FET", f"{case_id}: targetCarrier不符")
        require(header["priority"] == "Critical", f"{case_id}: priority不是Critical")
        require(header["deidentifyFlag"] == "1", f"{case_id}: deidentifyFlag不符")
        require(query["appType"] == expected_case["appType"], f"{case_id}: appType不符")
        require(query["ipdrOttFlag"] == expected_case["flag"], f"{case_id}: ipdrOttFlag不符")
        require(query["startTime"] == expected_case["start"], f"{case_id}: startTime不符")
        require(query["endTime"] == expected_case["end"], f"{case_id}: endTime不符")
        require(
            datetime.fromisoformat(query["startTime"].replace("Z", "+00:00"))
            < datetime.fromisoformat(query["endTime"].replace("Z", "+00:00")),
            f"{case_id}: 起訖時間無效",
        )
        expected_suffix = "_OTT.gpg" if query["ipdrOttFlag"] == "1" else "_IPDR.gpg"
        require(query["resultFile"].endswith(expected_suffix), f"{case_id}: resultFile suffix不符")
        require("," not in query["resultFile"], f"{case_id}: only單票不得有多個resultFile")
        require(metadata["resultFile"] == query["resultFile"], f"{case_id}: manifest resultFile不符")

        uuid.UUID(criteria["submissionId"])
        require(criteria["submissionId"] not in submission_ids, f"{case_id}: submissionId重複")
        require(query["submissionItemId"] not in item_ids, f"{case_id}: submissionItemId重複")
        submission_ids.add(criteria["submissionId"])
        item_ids.add(query["submissionItemId"])

        status = load_json(ROOT / metadata["statusFile"])
        require(status == {"submissionId": criteria["submissionId"]}, f"{case_id}: status payload不符")

    require(seen_cases == set(expected), "case集合不完整")
    all_payloads = load_json(ROOT / "_ALL.json")["submissions"]
    require(len(all_payloads) == 4, "_ALL.json數量不符")

    source_book = load_workbook(source, read_only=True, data_only=False)
    source_sheet = source_book[manifest["sheet"]]
    for metadata in manifest["submissions"]:
        row = metadata["sourceRow"]
        require(str(source_sheet.cell(row, 2).value).strip() == metadata["title"], f"來源B{row}不符")
        require(str(source_sheet.cell(row, 3).value).strip() == metadata["appType"], f"來源C{row}不符")
    source_book.close()

    output_book = load_workbook(ROOT / manifest["outputWorkbook"], data_only=False)
    require(output_book.sheetnames == ["投單清單", "欄位映射", "緊急映射", "來源與注意事項"], "輸出Excel sheets不符")
    require(output_book["投單清單"].max_row == 5, "投單清單筆數不符")
    require(output_book["欄位映射"].max_row == 5, "欄位映射筆數不符")
    require(output_book["緊急映射"]["B2"].value == "Critical", "Excel priority不符")
    formulas = []
    errors = []
    non_arial = []
    for sheet in output_book.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                if cell.data_type == "f":
                    formulas.append(f"{sheet.title}!{cell.coordinate}")
                if cell.data_type == "e":
                    errors.append(f"{sheet.title}!{cell.coordinate}={cell.value}")
                if cell.value is not None and cell.font.name != "Arial":
                    non_arial.append(f"{sheet.title}!{cell.coordinate}")
    require(not formulas, f"輸出Excel不應含公式: {formulas}")
    require(not errors, f"輸出Excel含錯誤值: {errors}")
    require(not non_arial, f"輸出Excel字型非Arial: {non_arial}")

    for name in ("send-one.sh", "query-status.sh", "run-all.sh"):
        require(os.access(ROOT / name, os.X_OK), f"{name}不可執行")
    print(
        "PASS submissions=4 queryItems=4 OTT=3 IPDR=1 targetCarrier=FET "
        "priority=Critical uniqueIds=4 formulas=0 excelErrors=0"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
