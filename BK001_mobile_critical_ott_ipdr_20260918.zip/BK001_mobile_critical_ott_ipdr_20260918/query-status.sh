#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "用法: $0 status/CRIT-17-FBVOICE-status.json" >&2
  exit 2
fi
status_file="$1"
[[ -f "$status_file" ]] || { echo "找不到狀態檔: $status_file" >&2; exit 2; }
command -v curl >/dev/null 2>&1 || { echo "找不到 curl" >&2; exit 2; }

endpoint="${BK002_ENDPOINT:-http://127.0.0.1:18080/api/ipdr/submission/status}"
headers=(-H "Content-Type: application/json")
curl_args=(--silent --show-error --connect-timeout "${BK002_CONNECT_TIMEOUT:-10}" --max-time "${BK002_MAX_TIME:-120}")
[[ -n "${BK001_AUTHORIZATION:-}" ]] && headers+=(-H "Authorization: ${BK001_AUTHORIZATION}")
[[ -n "${BK001_CLIENT_ID:-}" ]] && headers+=(-H "client_id: ${BK001_CLIENT_ID}")
[[ -n "${BK001_SUBSCRIPTION_KEY:-}" ]] && headers+=(-H "subscription-key: ${BK001_SUBSCRIPTION_KEY}")

request_uuid="${BK001_UUID:-}"
if [[ -z "$request_uuid" && "${BK001_AUTO_UUID:-0}" == "1" ]]; then
  command -v uuidgen >/dev/null 2>&1 || { echo "BK001_AUTO_UUID=1 需要 uuidgen" >&2; exit 2; }
  request_uuid="$(uuidgen | tr '[:upper:]' '[:lower:]')"
fi
[[ -n "$request_uuid" ]] && headers+=(-H "uuid: ${request_uuid}")

if [[ -n "${BK001_CA_FILE:-}" ]]; then
  curl_args+=(--cacert "$BK001_CA_FILE")
elif [[ "${BK001_INSECURE:-0}" == "1" ]]; then
  echo "WARNING: BK001_INSECURE=1，不可作為TLS驗收證據。" >&2
  curl_args+=(--insecure)
fi
curl "${curl_args[@]}" --request POST "${headers[@]}" --data-binary "@${status_file}" "$endpoint"
