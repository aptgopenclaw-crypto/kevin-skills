#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "用法: $0 create/CRIT-17-FBVOICE.json" >&2
  exit 2
fi
case_file="$1"
[[ -f "$case_file" ]] || { echo "找不到測試檔: $case_file" >&2; exit 2; }
command -v curl >/dev/null 2>&1 || { echo "找不到 curl" >&2; exit 2; }

endpoint="${BK001_ENDPOINT:-http://127.0.0.1:18080/api/ipdr/submission/create}"
headers=(-H "Content-Type: application/json")
curl_args=(--silent --show-error --connect-timeout "${BK001_CONNECT_TIMEOUT:-10}" --max-time "${BK001_MAX_TIME:-120}")
[[ -n "${BK001_AUTHORIZATION:-}" ]] && headers+=(-H "Authorization: ${BK001_AUTHORIZATION}")
[[ -n "${BK001_CLIENT_ID:-}" ]] && headers+=(-H "client_id: ${BK001_CLIENT_ID}")
[[ -n "${BK001_SUBSCRIPTION_KEY:-}" ]] && headers+=(-H "subscription-key: ${BK001_SUBSCRIPTION_KEY}")

request_uuid="${BK001_UUID:-}"
if [[ -z "$request_uuid" && "${BK001_AUTO_UUID:-0}" == "1" ]]; then
  command -v uuidgen >/dev/null 2>&1 || { echo "BK001_AUTO_UUID=1 需要 uuidgen" >&2; exit 2; }
  request_uuid="$(uuidgen | tr '[:upper:]' '[:lower:]')"
fi
[[ -n "$request_uuid" ]] && headers+=(-H "uuid: ${request_uuid}")

if [[ -n "${BK001_CA_FILE:-}" ]]; then
  curl_args+=(--cacert "$BK001_CA_FILE")
elif [[ "${BK001_INSECURE:-0}" == "1" ]]; then
  echo "WARNING: BK001_INSECURE=1，不可作為TLS驗收證據。" >&2
  curl_args+=(--insecure)
fi

response_file="$(mktemp)"
trap 'rm -f "$response_file"' EXIT
http_code="$(curl "${curl_args[@]}" --output "$response_file" --write-out "%{http_code}" --request POST "${headers[@]}" --data-binary "@${case_file}" "$endpoint")"
cat "$response_file"
printf '
HTTP_STATUS=%s
' "$http_code" >&2
[[ "$http_code" == "201" ]] || exit 1
if command -v jq >/dev/null 2>&1; then
  [[ "$(jq -r '.status // empty' "$response_file")" == "ACCEPTED" ]]
else
  grep -Eq '"status"[[:space:]]*:[[:space:]]*"ACCEPTED"' "$response_file"
fi
