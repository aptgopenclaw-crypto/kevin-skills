#!/usr/bin/env bash
set -uo pipefail
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "即將送出4張行網緊急測試單：3張OTT only、1張IPDR。"
confirm="${BK001_RUN_ALL_CONFIRM:-}"
if [[ "$confirm" != "YES" ]]; then
  read -r -p "確認執行？請輸入 YES: " confirm
fi
[[ "$confirm" == "YES" ]] || { echo "已取消。"; exit 2; }
response_dir="${BK001_RESPONSE_ROOT:-${script_dir}/responses}/$(date +%Y%m%d-%H%M%S)-$$"
mkdir -p "$response_dir"
cases=("CRIT-17-FBVOICE" "CRIT-19-IGVOICE" "CRIT-25-WECHAT" "CRIT-112-IGVIDEO")
passed=0
failed=0
for case_id in "${cases[@]}"; do
  case_file="${script_dir}/create/${case_id}.json"
  if "${script_dir}/send-one.sh" "$case_file" >"${response_dir}/${case_id}.log" 2>&1; then
    echo "${case_id} PASS"
    passed=$((passed + 1))
  else
    echo "${case_id} FAIL（${response_dir}/${case_id}.log）"
    failed=$((failed + 1))
    [[ "${BK001_CONTINUE_ON_FAILURE:-1}" == "1" ]] || exit 1
  fi
  sleep "${BK001_RUN_DELAY_SECONDS:-0}"
done
printf '總計=%d PASS=%d FAIL=%d
' "$((passed + failed))" "$passed" "$failed"
[[ "$failed" -eq 0 ]]
