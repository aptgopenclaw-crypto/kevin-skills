#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.12"
# dependencies = [
#   "openpyxl==3.1.5",
# ]
# [tool.uv]
# exclude-newer = "2026-09-18T00:00:00Z"
# ///

from __future__ import annotations

import argparse
import hashlib
import json
import re
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


ROOT = Path(__file__).resolve().parent
DEFAULT_SOURCE = Path(
    "/Users/ryanchen/Downloads/CIB-電信自測調取條件-20260729_Mobile_v3.xlsx"
)
DEFAULT_RUN_ID = "20260918"
SOURCE_SHEET = "OTT_APP調取"
LOCAL_TZ = ZoneInfo("Asia/Taipei")
PRIORITY_API = "Critical"
PRIORITY_SYSTEM = "critical"
PRIORITY_LABEL = "最速件"


@dataclass(frozen=True)
class CaseSpec:
    case_id: str
    source_row: int
    source_no: str
    expected_title: str
    expected_app: str
    ipdr_ott_flag: str
    requested_target: str


@dataclass(frozen=True)
class Case:
    spec: CaseSpec
    title: str
    app_type: str
    start_local: datetime
    end_local: datetime


CASE_SPECS = [
    CaseSpec(
        "CRIT-17-FBVOICE",
        8,
        "1.7",
        "Facebook voice call OTT辨識紀錄",
        "Facebook/Instagram Voice Calls",
        "1",
        "撈Facebook voice call；only OTT",
    ),
    CaseSpec(
        "CRIT-19-IGVOICE",
        10,
        "1.9",
        "Instagram voice call OTT辨識紀錄",
        "Facebook/Instagram Voice Calls",
        "1",
        "撈Facebook voice call；only OTT",
    ),
    CaseSpec(
        "CRIT-25-WECHAT",
        18,
        "2.5",
        "WeChat辨識紀錄",
        "WeChat Message",
        "0",
        "WeChat Message；IPDR",
    ),
    CaseSpec(
        "CRIT-112-IGVIDEO",
        13,
        "1.12",
        "Instagram video call OTT辨識紀錄",
        "Facebook/Instagram Video Calls",
        "1",
        "撈Facebook video call；only OTT",
    ),
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="產生BK001行網緊急OTT/IPDR模擬華電投單")
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--run-id", default=DEFAULT_RUN_ID)
    return parser.parse_args()


def source_no(value: object) -> str:
    if isinstance(value, (int, float)):
        return f"{value:g}"
    return str(value).strip()


def parse_time_range(value: object) -> tuple[datetime, datetime]:
    text = str(value or "").strip()
    matches = re.findall(
        r"(\d{4})[-/](\d{1,2})[-/](\d{1,2})\s+(\d{1,2}):(\d{2}):(\d{2})",
        text,
    )
    if len(matches) != 2:
        raise ValueError(f"無法解析時間區間: {text!r}")
    values = [datetime(*(int(part) for part in match), tzinfo=LOCAL_TZ) for match in matches]
    if values[0] >= values[1]:
        raise ValueError(f"起始時間必須早於結束時間: {text!r}")
    return values[0], values[1]


def utc_text(value: datetime) -> str:
    return value.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def local_text(value: datetime) -> str:
    return value.strftime("%Y-%m-%d %H:%M:%S")


def dump_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def load_cases(source: Path) -> list[Case]:
    workbook = load_workbook(source, read_only=True, data_only=False)
    if SOURCE_SHEET not in workbook.sheetnames:
        raise ValueError(f"來源Excel缺少sheet: {SOURCE_SHEET}")
    sheet = workbook[SOURCE_SHEET]
    cases = []
    for spec in CASE_SPECS:
        actual_no = source_no(sheet.cell(spec.source_row, 1).value)
        title = str(sheet.cell(spec.source_row, 2).value or "").strip()
        app_type = str(sheet.cell(spec.source_row, 3).value or "").strip()
        if actual_no != spec.source_no:
            raise ValueError(
                f"{SOURCE_SHEET}!A{spec.source_row}編號不符: {actual_no!r} != {spec.source_no!r}"
            )
        if title != spec.expected_title:
            raise ValueError(
                f"{SOURCE_SHEET}!B{spec.source_row}項目不符: {title!r} != {spec.expected_title!r}"
            )
        if app_type != spec.expected_app:
            raise ValueError(
                f"{SOURCE_SHEET}!C{spec.source_row}APP不符: {app_type!r} != {spec.expected_app!r}"
            )
        start, end = parse_time_range(sheet.cell(spec.source_row, 4).value)
        cases.append(Case(spec, title, app_type, start, end))
    workbook.close()
    return cases


def style_sheet(sheet) -> None:
    header_fill = PatternFill("solid", fgColor="1F4E78")
    for cell in sheet[1]:
        cell.font = Font(name="Arial", bold=True, color="FFFFFF")
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            cell.font = Font(name="Arial", size=10)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    for column in sheet.columns:
        width = min(max(len(str(cell.value or "")) for cell in column) + 2, 70)
        sheet.column_dimensions[get_column_letter(column[0].column)].width = max(width, 10)
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions


def build_workbook(
    submissions: list[dict], source: Path, source_hash: str, run_id: str
) -> str:
    workbook = Workbook()
    listing = workbook.active
    listing.title = "投單清單"
    listing.append([
        "Case", "來源編號", "來源列", "測試項目", "使用者指定", "appType",
        "targetCarrier", "priority", "系統priority", "系統顯示", "ipdrOttFlag",
        "結果檔", "本地開始", "本地結束", "UTC開始", "UTC結束",
        "submissionId", "submissionItemId", "create payload", "status payload",
    ])
    for item in submissions:
        listing.append([
            item["caseId"], item["sourceNo"], item["sourceRow"], item["title"],
            item["requestedTarget"], item["appType"], "FET", PRIORITY_API,
            PRIORITY_SYSTEM, PRIORITY_LABEL, item["ipdrOttFlag"], item["resultFile"],
            item["startLocal"], item["endLocal"], item["startUtc"], item["endUtc"],
            item["submissionId"], item["submissionItemId"], item["createFile"],
            item["statusFile"],
        ])

    mapping = workbook.create_sheet("欄位映射")
    mapping.append([
        "來源cell", "來源編號", "來源項目", "來源APP名稱", "API appType",
        "API ipdrOttFlag", "結果類型", "映射說明",
    ])
    for item in submissions:
        result_type = "OTT only" if item["ipdrOttFlag"] == "1" else "IPDR"
        mapping.append([
            f"{SOURCE_SHEET}!A{item['sourceRow']}:D{item['sourceRow']}",
            item["sourceNo"], item["title"], item["sourceApp"], item["appType"],
            item["ipdrOttFlag"], result_type,
            "appType依來源Excel APP名稱原值；結果類型依使用者指定。",
        ])

    priority = workbook.create_sheet("緊急映射")
    priority.append(["使用者需求", "BK001 priority", "系統 docPriority", "系統顯示", "依據"])
    priority.append([
        "緊急", PRIORITY_API, PRIORITY_SYSTEM, PRIORITY_LABEL,
        "BK001ServiceImpl.convertPriority(): Critical → critical；DocPriorityEnum.CRITICAL=最速件。",
    ])
    priority["B2"].comment = Comment(
        "BK001輸入值區分大小寫，緊急／最速件請使用Critical。", "Codex"
    )

    notes = workbook.create_sheet("來源與注意事項")
    notes.append(["項目", "內容"])
    rows = [
        ("來源檔", str(source)),
        ("來源SHA-256", source_hash),
        ("來源sheet", SOURCE_SHEET),
        ("來源列", "8（1.7）、10（1.9）、18（2.5）、13（1.12）"),
        ("網路", "行網，targetCarrier=FET"),
        ("緊急", "priority=Critical，後端轉為docPriority=critical，系統顯示最速件。"),
        ("結果類型", "1.7、1.9、1.12為ipdrOttFlag=1；2.5為ipdrOttFlag=0。"),
        ("APP映射", "APP名稱以本次來源Excel原值送入appType，不沿用舊測試包值。"),
        ("Facebook/Instagram", "來源Excel使用Facebook/Instagram共用Voice／Video Signature。"),
        ("時間", "來源時間視為Asia/Taipei（UTC+8），payload轉為UTC Z。"),
        ("去識別化", "使用者未另行指定，沿用同來源既有測試包deidentifyFlag=1。"),
        ("資料形式", "明文queryItems地端功能測試資料，不代表華電正式GPG加密／簽章封包。"),
        ("重送", f"同一run-id={run_id}會產生相同UUID；成功投單後應更換run-id。"),
    ]
    for row in rows:
        notes.append(row)

    for sheet in workbook.worksheets:
        style_sheet(sheet)
    output_name = f"CIB-華電API模擬投單-行網-緊急-FB_IG_WeChat-{run_id}.xlsx"
    workbook.save(ROOT / output_name)
    return output_name


def write_helpers(case_ids: list[str]) -> None:
    send_one = '''#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "用法: $0 create/CRIT-17-FBVOICE.json" >&2
  exit 2
fi
case_file="$1"
[[ -f "$case_file" ]] || { echo "找不到測試檔: $case_file" >&2; exit 2; }
command -v curl >/dev/null 2>&1 || { echo "找不到 curl" >&2; exit 2; }

endpoint="${BK001_ENDPOINT:-http://127.0.0.1:18080/api/ipdr/submission/create}"
headers=(-H "Content-Type: application/json")
curl_args=(--silent --show-error --connect-timeout "${BK001_CONNECT_TIMEOUT:-10}" --max-time "${BK001_MAX_TIME:-120}")
[[ -n "${BK001_AUTHORIZATION:-}" ]] && headers+=(-H "Authorization: ${BK001_AUTHORIZATION}")
[[ -n "${BK001_CLIENT_ID:-}" ]] && headers+=(-H "client_id: ${BK001_CLIENT_ID}")
[[ -n "${BK001_SUBSCRIPTION_KEY:-}" ]] && headers+=(-H "subscription-key: ${BK001_SUBSCRIPTION_KEY}")

request_uuid="${BK001_UUID:-}"
if [[ -z "$request_uuid" && "${BK001_AUTO_UUID:-0}" == "1" ]]; then
  command -v uuidgen >/dev/null 2>&1 || { echo "BK001_AUTO_UUID=1 需要 uuidgen" >&2; exit 2; }
  request_uuid="$(uuidgen | tr '[:upper:]' '[:lower:]')"
fi
[[ -n "$request_uuid" ]] && headers+=(-H "uuid: ${request_uuid}")

if [[ -n "${BK001_CA_FILE:-}" ]]; then
  curl_args+=(--cacert "$BK001_CA_FILE")
elif [[ "${BK001_INSECURE:-0}" == "1" ]]; then
  echo "WARNING: BK001_INSECURE=1，不可作為TLS驗收證據。" >&2
  curl_args+=(--insecure)
fi

response_file="$(mktemp)"
trap 'rm -f "$response_file"' EXIT
http_code="$(curl "${curl_args[@]}" --output "$response_file" --write-out "%{http_code}" --request POST "${headers[@]}" --data-binary "@${case_file}" "$endpoint")"
cat "$response_file"
printf '\nHTTP_STATUS=%s\n' "$http_code" >&2
[[ "$http_code" == "201" ]] || exit 1
if command -v jq >/dev/null 2>&1; then
  [[ "$(jq -r '.status // empty' "$response_file")" == "ACCEPTED" ]]
else
  grep -Eq '"status"[[:space:]]*:[[:space:]]*"ACCEPTED"' "$response_file"
fi
'''
    query_status = '''#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "用法: $0 status/CRIT-17-FBVOICE-status.json" >&2
  exit 2
fi
status_file="$1"
[[ -f "$status_file" ]] || { echo "找不到狀態檔: $status_file" >&2; exit 2; }
command -v curl >/dev/null 2>&1 || { echo "找不到 curl" >&2; exit 2; }

endpoint="${BK002_ENDPOINT:-http://127.0.0.1:18080/api/ipdr/submission/status}"
headers=(-H "Content-Type: application/json")
curl_args=(--silent --show-error --connect-timeout "${BK002_CONNECT_TIMEOUT:-10}" --max-time "${BK002_MAX_TIME:-120}")
[[ -n "${BK001_AUTHORIZATION:-}" ]] && headers+=(-H "Authorization: ${BK001_AUTHORIZATION}")
[[ -n "${BK001_CLIENT_ID:-}" ]] && headers+=(-H "client_id: ${BK001_CLIENT_ID}")
[[ -n "${BK001_SUBSCRIPTION_KEY:-}" ]] && headers+=(-H "subscription-key: ${BK001_SUBSCRIPTION_KEY}")

request_uuid="${BK001_UUID:-}"
if [[ -z "$request_uuid" && "${BK001_AUTO_UUID:-0}" == "1" ]]; then
  command -v uuidgen >/dev/null 2>&1 || { echo "BK001_AUTO_UUID=1 需要 uuidgen" >&2; exit 2; }
  request_uuid="$(uuidgen | tr '[:upper:]' '[:lower:]')"
fi
[[ -n "$request_uuid" ]] && headers+=(-H "uuid: ${request_uuid}")

if [[ -n "${BK001_CA_FILE:-}" ]]; then
  curl_args+=(--cacert "$BK001_CA_FILE")
elif [[ "${BK001_INSECURE:-0}" == "1" ]]; then
  echo "WARNING: BK001_INSECURE=1，不可作為TLS驗收證據。" >&2
  curl_args+=(--insecure)
fi
curl "${curl_args[@]}" --request POST "${headers[@]}" --data-binary "@${status_file}" "$endpoint"
'''
    quoted_cases = " ".join(f'"{case_id}"' for case_id in case_ids)
    run_all = f'''#!/usr/bin/env bash
set -uo pipefail
script_dir="$(cd "$(dirname "${{BASH_SOURCE[0]}}")" && pwd)"
echo "即將送出4張行網緊急測試單：3張OTT only、1張IPDR。"
confirm="${{BK001_RUN_ALL_CONFIRM:-}}"
if [[ "$confirm" != "YES" ]]; then
  read -r -p "確認執行？請輸入 YES: " confirm
fi
[[ "$confirm" == "YES" ]] || {{ echo "已取消。"; exit 2; }}
response_dir="${{BK001_RESPONSE_ROOT:-${{script_dir}}/responses}}/$(date +%Y%m%d-%H%M%S)-$$"
mkdir -p "$response_dir"
cases=({quoted_cases})
passed=0
failed=0
for case_id in "${{cases[@]}}"; do
  case_file="${{script_dir}}/create/${{case_id}}.json"
  if "${{script_dir}}/send-one.sh" "$case_file" >"${{response_dir}}/${{case_id}}.log" 2>&1; then
    echo "${{case_id}} PASS"
    passed=$((passed + 1))
  else
    echo "${{case_id}} FAIL（${{response_dir}}/${{case_id}}.log）"
    failed=$((failed + 1))
    [[ "${{BK001_CONTINUE_ON_FAILURE:-1}}" == "1" ]] || exit 1
  fi
  sleep "${{BK001_RUN_DELAY_SECONDS:-0}}"
done
printf '總計=%d PASS=%d FAIL=%d\n' "$((passed + failed))" "$passed" "$failed"
[[ "$failed" -eq 0 ]]
'''
    for name, content in {
        "send-one.sh": send_one,
        "query-status.sh": query_status,
        "run-all.sh": run_all,
    }.items():
        path = ROOT / name
        path.write_text(content, encoding="utf-8")
        path.chmod(0o755)


def write_readme(submissions: list[dict], source: Path, source_hash: str, run_id: str) -> None:
    rows = []
    for item in submissions:
        result_type = "OTT only" if item["ipdrOttFlag"] == "1" else "IPDR"
        rows.append(
            f"| {item['sourceNo']} | {item['title']} | `{item['appType']}` | "
            f"{item['startLocal']}～{item['endLocal'].split()[-1]} | `{item['ipdrOttFlag']}` ({result_type}) | "
            f"`create/{item['caseId']}.json` |"
        )
    table = "\n".join(rows)
    content = f'''# BK001 行網緊急 Facebook／Instagram／WeChat 模擬投單（{run_id}）

來源：`{source}` 之 `{SOURCE_SHEET}` sheet，SHA-256：`{source_hash}`。
本包依使用者指定建立4張BK001明文模擬華電投單，每張1個`queryItem`。

| 編號 | 測項 | appType | Asia/Taipei時間 | 結果類型 | Payload |
|---|---|---|---|---|---|
{table}

## 共用設定

- 行網：`targetCarrier=FET`。
- 緊急：`priority=Critical`，後端映射為`docPriority=critical`，系統顯示「最速件」。
- 使用者未另行指定去識別化，沿用同來源既有測試包：`deidentifyFlag=1`。
- 1.7、1.9、1.12使用`ipdrOttFlag=1`與單一`_OTT.gpg`結果檔。
- 2.5使用`ipdrOttFlag=0`與單一`_IPDR.gpg`結果檔。
- 時間依來源Excel視為`Asia/Taipei`，payload轉為UTC `Z`。
- 來源Excel的Facebook與Instagram Voice／Video共用APP Signature，payload依原值送出。

## 驗證與執行

```bash
UV_CACHE_DIR=/private/tmp/cib-uv-cache uv run --offline --python 3.12 \
  --with openpyxl==3.1.5 python validate_package.py

kubectl -n cib port-forward service/cibfn-back-api-service 18080:8080
export BK001_ENDPOINT='http://127.0.0.1:18080/api/ipdr/submission/create'
export BK002_ENDPOINT='http://127.0.0.1:18080/api/ipdr/submission/status'

./send-one.sh create/CRIT-17-FBVOICE.json
./query-status.sh status/CRIT-17-FBVOICE-status.json
BK001_RUN_ALL_CONFIRM=YES ./run-all.sh
```

如要用新的`run-id`重新產生UUID與整包資料：

```bash
UV_CACHE_DIR=/private/tmp/cib-uv-cache uv run --offline --python 3.12 \
  --with openpyxl==3.1.5 python generate_payloads.py --run-id <新run-id>
```

若走HTTPS Gateway，請設定`BK001_AUTHORIZATION`、`BK001_CLIENT_ID`、
`BK001_SUBSCRIPTION_KEY`與`BK001_CA_FILE`。正式TLS驗收不可使用
`BK001_INSECURE=1`。`_ALL.json`僅供人工檢視，不可直接POST。

## SQL核對

```sql
SELECT
    dqf.submission_id,
    od.lea_case_id,
    od.doc_priority,
    q.submission_item_id,
    q.query_status,
    q.query_start_time,
    q.query_end_time,
    q.app_type,
    q.ipdr_ott_flag,
    q.result_cib_path
FROM cibfn.tb_official_doc od
JOIN cibfn.tb_doc_query_form dqf ON dqf.official_doc_id = od.official_doc_id
JOIN cibfn.tb_query q ON q.doc_query_form_id = dqf.doc_query_form_id
WHERE od.lea_case_id LIKE 'FET-SELFTEST-{run_id}-CRIT-%'
ORDER BY od.lea_case_id;
```

此為明文`queryItems`地端功能測試資料，不代表華電正式`queryParameters`
GPG加密、簽章或密文竄改。
'''
    (ROOT / "_README.md").write_text(content, encoding="utf-8")


def main() -> int:
    args = parse_args()
    source = args.source.resolve()
    if not source.is_file():
        raise FileNotFoundError(source)
    source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    cases = load_cases(source)
    (ROOT / "create").mkdir(exist_ok=True)
    (ROOT / "status").mkdir(exist_ok=True)

    submissions = []
    all_payloads = []
    for case in cases:
        spec = case.spec
        submission_id = str(uuid.uuid5(
            uuid.NAMESPACE_URL,
            f"cib:bk001:mobile:critical:{args.run_id}:{spec.case_id}:{source_hash}",
        ))
        submission_item_id = f"{spec.case_id}-{args.run_id}"
        suffix = "OTT" if spec.ipdr_ott_flag == "1" else "IPDR"
        result_file = f"FET-{spec.case_id}_{suffix}.gpg"
        payload = {
            "lawfulRequest": {
                "requestHeader": {
                    "leaCaseId": f"FET-SELFTEST-{args.run_id}-{spec.case_id}",
                    "requestingAgency": "FET電信自測",
                    "policeRequestId": f"SELFTEST-{args.run_id}-{spec.case_id}",
                    "caseReason": f"電信自測-緊急-行網-{spec.source_no} {case.title}",
                    "legalBasis": "電信自測",
                    "dataUsage": "系統驗證",
                    "contactName": "許豪",
                    "targetCarrier": "FET",
                    "priority": PRIORITY_API,
                    "remarks": (
                        f"來源：{source.name} / {SOURCE_SHEET} / Excel列{spec.source_row}；"
                        f"{spec.requested_target}"
                    ),
                    "deidentifyFlag": "1",
                },
                "queryCriteria": {
                    "submissionId": submission_id,
                    "resultDirectory": (
                        f"/ipdr_results/fet/selftest/{args.run_id}/mobile/critical-ott-ipdr/"
                        f"{spec.case_id}/{submission_id}"
                    ),
                    "queryItems": [{
                        "submissionItemId": submission_item_id,
                        "resultFile": result_file,
                        "ipdrOttFlag": spec.ipdr_ott_flag,
                        "startTime": utc_text(case.start_local),
                        "endTime": utc_text(case.end_local),
                        "appType": case.app_type,
                    }],
                },
            }
        }
        create_file = f"create/{spec.case_id}.json"
        status_file = f"status/{spec.case_id}-status.json"
        dump_json(ROOT / create_file, payload)
        dump_json(ROOT / status_file, {"submissionId": submission_id})
        metadata = {
            "caseId": spec.case_id,
            "sourceRow": spec.source_row,
            "sourceNo": spec.source_no,
            "sourceCells": f"{SOURCE_SHEET}!A{spec.source_row}:D{spec.source_row}",
            "title": case.title,
            "sourceApp": case.app_type,
            "appType": case.app_type,
            "requestedTarget": spec.requested_target,
            "startLocal": local_text(case.start_local),
            "endLocal": local_text(case.end_local),
            "startUtc": utc_text(case.start_local),
            "endUtc": utc_text(case.end_local),
            "ipdrOttFlag": spec.ipdr_ott_flag,
            "resultFile": result_file,
            "submissionId": submission_id,
            "submissionItemId": submission_item_id,
            "createFile": create_file,
            "statusFile": status_file,
            "qgwTicketCount": 1,
        }
        submissions.append(metadata)
        all_payloads.append({"metadata": metadata, "payload": payload})

    output_workbook = build_workbook(submissions, source, source_hash, args.run_id)
    manifest = {
        "source": source.name,
        "sourcePath": str(source),
        "sourceSha256": source_hash,
        "sheet": SOURCE_SHEET,
        "sourceRows": [item["sourceRow"] for item in submissions],
        "sourceNumbers": [item["sourceNo"] for item in submissions],
        "runId": args.run_id,
        "networkType": "MOBILE",
        "targetCarrier": "FET",
        "priority": {
            "requestedLabel": "緊急",
            "apiValue": PRIORITY_API,
            "systemValue": PRIORITY_SYSTEM,
            "systemLabel": PRIORITY_LABEL,
        },
        "deidentifyFlag": "1",
        "submissionCount": len(submissions),
        "queryItemCount": len(submissions),
        "ottCount": sum(item["ipdrOttFlag"] == "1" for item in submissions),
        "ipdrCount": sum(item["ipdrOttFlag"] == "0" for item in submissions),
        "qgwTicketCountIfAllReleased": len(submissions),
        "outputWorkbook": output_workbook,
        "submissions": submissions,
    }
    dump_json(ROOT / "manifest.json", manifest)
    dump_json(ROOT / "_ALL.json", {"submissions": all_payloads})
    write_helpers([case.spec.case_id for case in cases])
    write_readme(submissions, source, source_hash, args.run_id)
    print(
        f"generated submissions={len(submissions)} queryItems={len(submissions)} "
        f"OTT={manifest['ottCount']} IPDR={manifest['ipdrCount']} priority={PRIORITY_API}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
